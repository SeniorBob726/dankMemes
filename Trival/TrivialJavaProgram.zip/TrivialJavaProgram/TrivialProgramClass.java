/**
 * The TrivialProgramClass provides the main function for a trivially
 * simple Java program (which currently does nothing).
 * <br> <br>
 * Created: <br>
 *   23 March 2008,  Alyce Brady<br>
 * <br>
 * Modifications: <br>
 *   (date), (your name), Modified to .... <br>
 * 
 * @author (your name) (with assistance from)
 * @version 23 March 2008
 */
public class TrivialProgramClass
{
    /**
     *  This is the main function for a trivially simple Java application
     *  (which currently does absolutely nothing).
     *  @param    String args[] is never used
     **/
    public static void main(String[] args)
    {
    }

}
